import numpy as np
import torch.nn as nn
import torch

def get_pad_mask(seq, pad_idx):
    """
    生成padding掩码: True=mask遮蔽，False=有效token
    seq: [B, L]
    return: [B, 1, L]
    """
    mask = (seq != pad_idx).unsqueeze(1)
    return ~mask

def get_subsequent_mask(seq):
    """
    生成上三角掩码，遮蔽未来位置
    return: [B, L, L]
    """
    b, l = seq.size()
    mask = torch.triu(torch.ones(l, l, dtype=torch.bool, device=seq.device), diagonal=1)
    mask = mask.unsqueeze(0).expand(b, -1, -1)
    return mask


class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, num_heads, dropout=0.1):
        super().__init__()
        assert d_model % num_heads == 0
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        self.dropout = nn.Dropout(dropout)

        self.W_Q = nn.Linear(d_model, d_model)
        self.W_K = nn.Linear(d_model, d_model)
        self.W_V = nn.Linear(d_model, d_model)
        self.W_O = nn.Linear(d_model, d_model)

        nn.init.xavier_uniform_(self.W_Q.weight)
        nn.init.xavier_uniform_(self.W_K.weight)
        nn.init.xavier_uniform_(self.W_V.weight)
        nn.init.xavier_uniform_(self.W_O.weight)

    def forward(self, Q, K, V, mask=None):
        b = Q.size(0)

        # 线性投影 + 分头: [B, L, heads, dk] -> [B, heads, L, dk]
        Q = self.W_Q(Q).view(b, -1, self.num_heads, self.d_k).transpose(1, 2)
        K = self.W_K(K).view(b, -1, self.num_heads, self.d_k).transpose(1, 2)
        V = self.W_V(V).view(b, -1, self.num_heads, self.d_k).transpose(1, 2)

        # 注意力分数
        scores = torch.matmul(Q, K.transpose(-1, -2)) / np.sqrt(self.d_k)

        if mask is not None:
            # mask扩展head维度 [B,1,L,L] 自动广播到heads
            scores = scores.masked_fill(mask.unsqueeze(1), -1e9)

        scores = self.dropout(torch.softmax(scores, dim=-1))
        output = torch.matmul(scores, V)

        # 拼接多头
        output = output.transpose(1, 2).contiguous().view(b, -1, self.d_model)
        output = self.W_O(output)
        return output


class PositionwiseFeedForward(nn.Module):
    def __init__(self, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.w1 = nn.Linear(d_model, d_ff)
        self.w2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.w1(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.w2(x)
        return x


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000, dropout=0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))

        pe[:, 0::2] = torch.sin(pos * div_term)
        pe[:, 1::2] = torch.cos(pos * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)  # buffer，不参与梯度更新

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)


class EncoderLayer(nn.Module):
    """ Pre-LN Encoder层：先归一化，再子层 """
    def __init__(self, d_model, num_heads, d_ff, dropout=0.1):
        super().__init__()
        self.self_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.ffn = PositionwiseFeedForward(d_model, d_ff, dropout)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, x, src_mask):
        residual = x
        x = self.norm1(x)
        x = self.self_attn(x, x, x, src_mask)
        x = self.dropout1(x)
        x = residual + x

        residual = x
        x = self.norm2(x)
        x = self.ffn(x)
        x = self.dropout2(x)
        x = residual + x
        return x


class DecoderLayer(nn.Module):
    """ Pre-LN Decoder层：自注意力 -> 交叉注意力 -> FFN """
    def __init__(self, d_model, num_heads, d_ff, dropout=0.1):
        super().__init__()
        self.mask_self_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.cross_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.ffn = PositionwiseFeedForward(d_model, d_ff, dropout)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.norm3 = nn.LayerNorm(d_model)

        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.dropout3 = nn.Dropout(dropout)

    # ✅ 修复：增加输入x
    def forward(self, x, enc_out, tgt_mask, src_tgt_mask):
        # 目标自注意力（带future mask）
        residual = x
        x = self.norm1(x)
        x = self.mask_self_attn(x, x, x, tgt_mask)
        x = self.dropout1(x)
        x = residual + x

        # 交叉注意力 Q来自decoder，K/V来自encoder输出
        residual = x
        x = self.norm2(x)
        x = self.cross_attn(x, enc_out, enc_out, src_tgt_mask)
        x = self.dropout2(x)
        x = residual + x

        # FFN
        residual = x
        x = self.norm3(x)
        x = self.ffn(x)
        x = self.dropout3(x)
        x = residual + x
        return x


class Encoder(nn.Module):
    def __init__(self, src_vocab_size, d_model, num_heads, d_ff, num_layers, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.src_emb = nn.Embedding(src_vocab_size, d_model)
        self.pos_enc = PositionalEncoding(d_model, dropout=dropout)
        self.layers = nn.ModuleList([
            EncoderLayer(d_model, num_heads, d_ff, dropout) for _ in range(num_layers)
        ])

    def forward(self, src_seq, src_mask):
        x = self.src_emb(src_seq) * np.sqrt(self.d_model)
        x = self.pos_enc(x)
        for layer in self.layers:
            x = layer(x, src_mask)
        return x


class Decoder(nn.Module):
    def __init__(self, tgt_vocab_size, d_model, num_heads, d_ff, num_layers, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.tgt_emb = nn.Embedding(tgt_vocab_size, d_model)
        self.pos_enc = PositionalEncoding(d_model, dropout=dropout)
        self.layers = nn.ModuleList([
            DecoderLayer(d_model, num_heads, d_ff, dropout) for _ in range(num_layers)
        ])

    def forward(self, enc_out, tgt_seq, tgt_mask, src_tgt_mask):
        x = self.tgt_emb(tgt_seq) * np.sqrt(self.d_model)
        x = self.pos_enc(x)
        # ✅ 修复：传入x
        for layer in self.layers:
            x = layer(x, enc_out, tgt_mask, src_tgt_mask)
        return x


class Transformer(nn.Module):
    def __init__(self, src_vocab_size, tgt_vocab_size, d_model=512, num_heads=8, d_ff=2048, num_layers=6, max_len=5000, pad_idx=0, dropout=0.1):
        super().__init__()
        self.pad_idx = pad_idx
        self.encoder = Encoder(src_vocab_size, d_model, num_heads, d_ff, num_layers, dropout)
        self.decoder = Decoder(tgt_vocab_size, d_model, num_heads, d_ff, num_layers, dropout)
        self.projection = nn.Linear(d_model, tgt_vocab_size)

    def forward(self, src_seq, tgt_seq):
        src_mask = get_pad_mask(src_seq, self.pad_idx)
        tgt_pad_mask = get_pad_mask(tgt_seq, self.pad_idx)
        tgt_sub_mask = get_subsequent_mask(tgt_seq)
        tgt_mask = tgt_pad_mask | tgt_sub_mask  # 同时屏蔽padding和future token
        src_tgt_mask = src_mask

        enc_out = self.encoder(src_seq, src_mask)
        dec_out = self.decoder(enc_out, tgt_seq, tgt_mask, src_tgt_mask)
        logits = self.projection(dec_out)
        return logits

    @torch.no_grad()
    def greedy_infer(self, src_seq, max_gen_len=50, bos_idx=20, eos_idx=30):
        self.eval()
        src_mask = get_pad_mask(src_seq, self.pad_idx)
        enc_out = self.encoder(src_seq, src_mask)  # ✅ 修复变量名
        tgt_seq = torch.tensor([[bos_idx]], device=src_seq.device)

        for _ in range(max_gen_len):
            tgt_pad_mask = get_pad_mask(tgt_seq, self.pad_idx)
            tgt_sub_mask = get_subsequent_mask(tgt_seq)
            tgt_mask = tgt_pad_mask | tgt_sub_mask
            src_tgt_mask = src_mask

            dec_out = self.decoder(enc_out, tgt_seq, tgt_mask, src_tgt_mask)
            logits = self.projection(dec_out)
            next_token = logits[:, -1, :].argmax(dim=-1, keepdim=True)
            tgt_seq = torch.cat([tgt_seq, next_token], dim=-1)

            if next_token.item() == eos_idx:
                break
        return tgt_seq.squeeze(0).tolist()


if __name__ == "__main__":
    src_vocab = 1000
    tgt_vocab = 1000
    pad_idx = 0
    bos_idx = 2
    eos_idx = 3
    d_model = 512
    num_heads = 8
    d_ff = 2048
    layers = 6

    model = Transformer(src_vocab, tgt_vocab, d_model, num_heads, d_ff, layers, pad_idx=pad_idx)

    batch_size = 4
    src_len = 12
    tgt_len = 10
    src = torch.randint(1, src_vocab, (batch_size, src_len))
    tgt = torch.randint(1, tgt_vocab, (batch_size, tgt_len))

    logits = model(src, tgt)
    print("训练前向 logits shape:", logits.shape)  # [4, 10, 1000]

    # 测试贪心推理
    src_single = torch.randint(1, src_vocab, (1, src_len))
    pred = model.greedy_infer(src_single, max_gen_len=30, bos_idx=bos_idx, eos_idx=eos_idx)
    print("贪心推理结果token序列：", pred)
